def sayHello():
    print("Yes")
