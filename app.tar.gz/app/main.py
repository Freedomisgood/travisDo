import datetime


def printTimeNow():
    return datetime.datetime.now()


if __name__ == '__main__':
    res = printTimeNow()
    print(res)
